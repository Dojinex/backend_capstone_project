from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsAdmin(BasePermission):
    """
    Allows access only to admin users.
    Works for both staff/superuser and role-based ADMIN.
    """
    def has_permission(self, request, view):
        return (
            request.user.is_authenticated and
            (
                request.user.is_staff or
                request.user.is_superuser or
                getattr(request.user, "role", None) == "ADMIN"
            )
        )


class IsTeacher(BasePermission):
    def has_permission(self, request, view):
        return (
            request.user.is_authenticated and
            getattr(request.user, "role", None) == "TEACHER"
        )


class IsStudent(BasePermission):
    def has_permission(self, request, view):
        return (
            request.user.is_authenticated and
            getattr(request.user, "role", None) == "STUDENT"
        )


class IsAdminOrTeacher(BasePermission):
    def has_permission(self, request, view):
        return (
            request.user.is_authenticated and
            getattr(request.user, "role", None) in ["ADMIN", "TEACHER"]
        )


class ReadOnlyOrAdmin(BasePermission):
    """
    Read-only access for authenticated users.
    Write access only for ADMIN.
    """
    def has_permission(self, request, view):
        # Allow safe methods (GET, HEAD, OPTIONS) for authenticated users
        if request.method in SAFE_METHODS:
            return request.user.is_authenticated

        # Write access only for ADMIN
        return (
            request.user.is_authenticated and
            getattr(request.user, "role", None) == "ADMIN"
        )